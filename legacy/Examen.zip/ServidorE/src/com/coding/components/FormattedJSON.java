package com.coding.components;

public class FormattedJSON {
}
